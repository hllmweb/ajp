function Contato(){
    return(
        <>
            Contato
        </>
    );
}

export default Contato;