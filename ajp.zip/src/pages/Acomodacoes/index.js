import Header from './../../components/Header'

function Acomodacoes(){
    return(
        <>  
            <Header />
            <h2>Acomodacoes</h2>
        </>
    );
}

export default Acomodacoes;